#include "TAbleauborne.h"

TAbleauborne::TAbleauborne(int taille, float b1, float b2)
	:Tableau(taille)
{
	this->b1 = b1;
	this->b2 = b2;
}
