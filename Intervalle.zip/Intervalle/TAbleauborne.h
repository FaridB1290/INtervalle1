#pragma once
#include "Tableau.h"
class TAbleauborne :public Tableau
{
private :
	float b1;
	float b2;
public:
	TAbleauborne(int taille, float b1, float b2);
	
};

